package exceptions;

public class TryCatch {

	public static void main(String[] args) {
		
		
		System.out.println("Exception Handling using try and catch block : \n");
		
		
		
		
		try {
			int a =15/0;
			
		}
		catch (ArithmeticException e){
			System.out.println("Arithemetic Exception : \n");
			System.out.println(e.toString()+ "\n");
		}
		
		try {
			int arr[] = {1,2,3};
			arr[5] = 10;
			
		}
		
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println("ArrayIndexOutOfBounds Exception : \n");
			System.out.println(e.toString());
		}

	}

}
