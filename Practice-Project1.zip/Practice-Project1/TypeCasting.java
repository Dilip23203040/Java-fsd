package lesson12;

public class TypeCasting {

	public static void main(String[] args) {
		
		/* Primitive Type casting
		 	
		 	Converting one type of primitive datatype to another type of primitive datatype.
		 	
		 	Narrowing ( Explicit type casting)
		 	
		 	Converting higher datatype to lower datatype.
		 	
		*/
		
		System.out.println("Explicit Type Casting \n");
		
		float a = 2.7f; // higher datatype
		
		int b = (int)a; // converting to lower datatype
		
		System.out.println("a :" + a);
		
		System.out.println("b :" + b + "\n");
		
		/* Widening ( Implicit type casting )
		
			Converting lower datatype to higher datatype
		 	
		*/
		
		System.out.println("Implicit Type Casting \n" );
		
		int c = 1000;
		
		double d = c; // double d = (double)c;
		
		char e = 'D';
		
		int f = e;
		
		System.out.println("c :" + c);
		System.out.println("d :" + d);
		System.out.println("e :" + e);
		System.out.println("f :" + f); // It will print the ASCII value of D = 68
		
		
	}
	

}
