package com.ecommerce.dao;

import java.sql.ResultSet;    
import java.sql.SQLException;    
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;    
import org.springframework.jdbc.core.JdbcTemplate;    
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.ecommerce.entity.EProduct;
 

@Repository
public class EProductDAO {

	@Autowired
	SessionFactory sf;
	
	public List<EProduct> findAllProduct() {
		Session session = sf.openSession();
		TypedQuery <EProduct> qry = session.createQuery("from EProduct");
		List<EProduct> listOfProduct = qry.getResultList();
		return listOfProduct;
	}
}
        
