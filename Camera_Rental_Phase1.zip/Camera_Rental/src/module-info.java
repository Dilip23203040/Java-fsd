/**
 * 
 */
/**
 * @author Sammy
 *
 */
module Camera_Rental {
}