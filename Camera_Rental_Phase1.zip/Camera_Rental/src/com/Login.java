package com;

import java.util.Scanner;
import exceptions.*;

public class Login {
	
	public static void main(String[] args) throws LoginException {
	// TODO Auto-generated method stub

    System.out.println("---------------------------------------");
	System.out.println("| Welcome to Camera Rental Shop |");
	System.out.println("---------------------------------------");
	do {
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter your username: ");
	String username=sc.next();

	System.out.println("Enter your Password: ");
	String password=sc.next();
	
	if(username.equals("admin") && password.equals("admin123")) {
        CameraOperations.InitializeList();
        
        System.out.println("Created by 2kLearners");
		mainMenu();
	}
	else {
	   
		System.out.println("| Invalid login credentials |");
		
	}
	}while(true);

	}
	
	public static void subMenu() {
		System.out.println("Choose your choice ");
		System.out.println("1. Add");
		System.out.println("2. Remove");
		System.out.println("3. View my cameras");
		System.out.println("4. Go to Previous menu");

		Scanner sc=new Scanner(System.in);
	
		int choice=sc.nextInt();
		//nested switch
		switch(choice) {
			case 1://add

				CameraOperations.addCamera();
				subMenu();
				break;
				
				
			case 2: //remove
				CameraOperations.displayAllCameras();
				System.out.println("Enter Camera id to delete");
			    int id=sc.nextInt();
			    CameraOperations.remove(id);	
			    subMenu();
			    break;
			    
			    case 3://view my camera
			    	CameraOperations.displayAllCameras();
					subMenu();
		    	
			    	break;
			    case 4://go back to previous menu
			    	 mainMenu();
			    	break;
			    	 }
		

		
		
	}
	
	
	
	
	public static void mainMenu() {
		Scanner sc =new Scanner(System.in);
		System.out.println("Choose your choice ");
		System.out.println("1. My camera");
		System.out.println("2. Rent a camera");
		System.out.println("3. View All camera");
		System.out.println("4. My Wallet");
		System.out.println("5. Exit");
		int option=sc.nextInt();

		switch(option) {

		case 1: 
			
			subMenu();
			break;
			
		
		case 2:
			CameraOperations.rentCamera();
	    	 mainMenu();

			break;
			
		case 3:
			
			ViewAllCameras.view();
	    	 mainMenu();

			break;
		
			
		case 4:
			Wallet.manageWallet();
	    	 mainMenu();

			break;
			
		case 5:
			System.exit(0);
		
        default:
        	System.out.println("Invalid option choosen");
        	System.out.println("choose a range between 1-5");
        	mainMenu();

		}
	
}

}
