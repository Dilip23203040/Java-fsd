package maps;

import java.util.*;

public class Treemap {

	public static void main(String[] args) {


		TreeMap<Integer,String> tm=new TreeMap<Integer,String>(); 
		
		tm.put(8, "Hari");
		tm.put(9, "Batu");
		tm.put(10, "chari");
		
		for(Map.Entry m3: tm.entrySet()) {
			
			System.out.println(m3.getKey()+ " "+ m3.getValue());
			
		}
		

	}

}
