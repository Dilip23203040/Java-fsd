package maps;

import java.util.*;

public class Hashmap {
	
	public static void main(String[] args) {
		
		HashMap <Integer,String> hm = new HashMap<Integer,String>();
		
		hm.put(1, "sam");
		hm.put(2, "dil");
		hm.put(3, "raja");
		
		for(Map.Entry m1: hm.entrySet() ) {
			
			System.out.println(m1.getKey()+" "+m1.getValue());
			
		}
		
	}

}
