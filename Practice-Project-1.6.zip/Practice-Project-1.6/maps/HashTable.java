package maps;

import java.util.*;

public class HashTable {

	public static void main(String[] args) {
		
		Hashtable<Integer,String> ht = new Hashtable<Integer,String>();
		
		ht.put(4,"Jhon");
		ht.put(5,"Sammy");
		ht.put(6,"James");
		ht.put(7,"Araku");
		
		for(Map.Entry m2: ht.entrySet()) {
			
			System.out.println(m2.getKey()+ " "+m2.getValue());
			
		}


	}

}
