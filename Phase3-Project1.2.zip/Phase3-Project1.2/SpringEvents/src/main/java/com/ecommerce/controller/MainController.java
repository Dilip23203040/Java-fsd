package com.ecommerce.controller;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ecommerce.beans.CustomEventPublisher;

@Controller
public class MainController {


        
           @RequestMapping(value = "customevent", method = RequestMethod.GET)
            public String customEvent(ModelMap map)
            {
                   
              ApplicationContext context = new ClassPathXmlApplicationContext("dispatcher-servlet.xml");
                CustomEventPublisher cvp =
                        (CustomEventPublisher) context.getBean("customEventPublisher");
                     
                cvp.publish();  
                cvp.publish();
                return "customEvent";
            }
           
}