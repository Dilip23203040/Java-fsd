package exceptions;

public class ThrowDemo1 {
	
	public static void main(String[] args) {
		
		int a=8, b=0, result;
		
		
		
		try {
			if(b==0) {
				throw new ArithmeticException("Can't divide by zero");
			}
			else {
				result=a/b;
				System.out.println(result);
			}
		}catch(ArithmeticException e) {
			System.out.println(e.toString());
		}
		
	}

}
