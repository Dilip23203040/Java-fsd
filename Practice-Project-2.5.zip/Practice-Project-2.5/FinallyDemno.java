package exceptions;

public class FinallyDemno {

	public static void main(String[] args) {
		
		int arr[] = {0,1,3};
		
		try {
			arr[3] = 7;
		}
		catch (ArrayIndexOutOfBoundsException e){
			
			System.out.println(e.toString()+ "\n");
			
		}
		
		finally {
			for(int i=0;i<arr.length;i++) {
				System.out.println(arr[i]);
			}
		}
	}

}
