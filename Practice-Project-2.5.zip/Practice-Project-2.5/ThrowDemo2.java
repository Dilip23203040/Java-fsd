package exceptions;

public class ThrowDemo2 {
	
	void div() throws ArithmeticException{
		int a=8, b=0, result;
		
		result = a/b;
	}

	public static void main(String[] args) {
		
		ThrowDemo2 td1 = new ThrowDemo2();
		
		try {
			td1.div();
		}
		catch(ArithmeticException e) {
			System.out.println(e.toString());
		}

	}

}
