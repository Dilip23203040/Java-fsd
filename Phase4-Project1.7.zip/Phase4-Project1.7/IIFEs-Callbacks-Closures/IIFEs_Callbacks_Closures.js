const empId = (function() {
    let count = 0;
    return function() {
      ++count;
      return `emp${count}`;
    };
  })();
  
  document.write("<br/>New Emplyee IDs are listed here");
  document.write("<br/>Alex: "+empId()); 
  document.write("<br/>Dexter: "+empId()); 
  document.write("<br/>Annie: "+empId());
   

  //Callbacks
  document.write("<br/>"); //to start the output from the neext line
  function fullName(firstName, lastName, callback){
    document.write("<br/>My name is " + firstName + " " + lastName);
    callback(lastName);
  }
  
  var greeting = function(ln){
    document.write("<br/>Welcome " + ln);
  };
  
  fullName("Alex", "Wilson", greeting);
  document.write("<br/>");
  fullName("Dexter", "Johnson", greeting);
  document.write("<br/>");
  fullName("Annie", "Butler", greeting);
  