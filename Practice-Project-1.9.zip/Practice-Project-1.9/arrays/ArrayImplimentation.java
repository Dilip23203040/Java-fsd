package arrays;



public class ArrayImplimentation {
	
	public static void main(String[] args) {
		
		//Single dimensional array;
		
		int arr1[] = {90,11,34,67,90};
		
		for(int i=0;i<arr1.length;i++) {
			
			System.out.println("Elements of array :" + arr1[i] +"\n");
			
		}
		
		int[][] arr2 = { {2,3,4,5}, {67,8,9,7}, {3,8,5,6,90} } ;
		
		System.out.println("Length of row1 :" + arr2[0].length);

	}
}