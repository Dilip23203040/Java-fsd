package exampleAM;

public class PublicAMExample {
	
	public void pubAM3() {
		
		System.out.println("Public access modifier");
		
	}

}
