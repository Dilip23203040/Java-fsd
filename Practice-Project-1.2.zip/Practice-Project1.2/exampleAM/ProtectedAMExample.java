package exampleAM;

public class ProtectedAMExample {
	
protected void proAM() {
		
		System.out.println("Protected access specifier");
		
	}

}
