package mainAM;

public class PrivateAM {
	
	private void priAM() {
		
		System.out.println("Private access specifier");
		
	}
	
	public static void main(String[] args) {
		
		// It can access within the class where they are created.
		
		PrivateAM Pi = new PrivateAM();
		
		Pi.priAM();
		
		PrivateAMExample pi2 = new PrivateAMExample();
		
		//pi2.priAM2();  we can't access because the method is private and it is in another class.
		
	}

}



 class PrivateAMExample{
	
	 private void priAM2() {
		 
		 System.out.println("Private access modifier in another class");
		 
	 }
	
}
