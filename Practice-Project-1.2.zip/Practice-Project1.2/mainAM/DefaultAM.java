package mainAM;

public class DefaultAM {

	public static void main(String[] args) {
		
		// Default access modifier can access within the package.
		
		DefaultAM1 d = new DefaultAM1();
		
		d.Def();

	}
	
	

}



class DefaultAM1 {
	
	void Def() {
		
		System.out.println("Default access modifier");
		
	}
	
}