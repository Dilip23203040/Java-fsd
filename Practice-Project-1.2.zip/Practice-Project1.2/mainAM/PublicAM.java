package mainAM;

import exampleAM.*;

public class PublicAM {
	

	public static void main(String[] args) {
		
		// Public access modifier can be accessed through out the class, outside the class and outside the package.
	
		PublicAMExample p3 = new PublicAMExample();
		
		p3.pubAM3();
	}

	

	}

	