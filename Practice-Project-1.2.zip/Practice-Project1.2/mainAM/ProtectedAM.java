package mainAM;

import exampleAM.*;

public class ProtectedAM extends ProtectedAMExample {

	public static void main(String[] args) {
		
		// It can access within the same class, subclasses, and classes in the same package and in different package.
		
		ProtectedAM pr = new ProtectedAM();
		
		pr.proAM();
		

	}
}

