package thread;

public class ExtendingThread extends Thread {
	
	public void run() {
		System.out.println("Thread is running ");
	}

	public static void main(String[] args) {

		ExtendingThread et =  new ExtendingThread();
		et.start();
	}

}
