package collections;

import java.util.*;

public class HashColle {

	public static void main(String[] args) {
		
		HashSet<Integer> h = new HashSet<Integer>();
		
		   h.add(101);  
	       h.add(103); 
	       h.add(105);
	       h.add(102);
	       h.add(104);
		
		
		System.out.println(h);
		

	}

}
