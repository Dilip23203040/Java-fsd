package collections;

import java.util.*;

public class ArrayColle {
	
	public static void main(String[] args) {
		
		ArrayList <Integer> a= new ArrayList <Integer> ();
		
		a.add(101);
		a.add(102);
		a.add(103);
		a.add(104);
		a.add(105);
		
		System.out.println(a);
		
	}

}
