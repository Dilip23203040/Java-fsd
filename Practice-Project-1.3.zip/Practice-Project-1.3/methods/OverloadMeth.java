package methods;

public class OverloadMeth {
	
	public void Over(int a, int b) {
		
		System.out.println(a/b);
		
	}
	
public void Over(String s1) {
		
		System.out.println(s1);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		OverloadMeth O = new OverloadMeth();
		
		O.Over(10, 2);
		O.Over("Method Overloading");

	}

}
