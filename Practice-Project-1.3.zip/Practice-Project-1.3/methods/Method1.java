package methods;

public class Method1 {
	
	
	
	public int add(int a, int b) {
		
		return a+b;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Method1 M1 = new Method1();
		
		int z = M1.add(8,34);
		
		System.out.println("Addition of two numbers is :" + z);

	}

}
