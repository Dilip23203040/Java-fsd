package methods;

public class CallMeth {

	int a;
	int b ;
	int m;
	
	public int mul(int a, int b) {
		
		this.a = a;
		this.b = b;
		
		m=a*b;
		
		return m;
		
	}
	
	public static void main(String[] args) {
		
		CallMeth M2 = new CallMeth();
		System.out.println("Befor Calling :" + M2.m +"\n");
		M2.mul(10,20);
		System.out.println("After calling :" + M2.m);
		

	}

}
