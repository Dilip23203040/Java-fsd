package constructor;

public class Paracon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1 = new Student(58, "Dilip", "Branch");
		
		System.out.println("\n");
		
		Student s2 = new Student(54, "Revanth", "Mech");
		
		
		
	}

}


class Student {
	
	int sid;
	String sname;
	String Branch;
	
	Student(int sid, String sname, String Branch){
		
		this.sid = sid;
		this.sname = sname;
		this.Branch = Branch;
		
		System.out.println("Student id :" + sid + "\n" + "Student Name :" + sname + "\n" + "Student Branch :" + Branch );
		
	}
	
}