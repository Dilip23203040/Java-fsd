package constructor;

public class DefaultCon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DefEg d1 = new DefEg();
		DefEg d2 = new DefEg();
		
		d1.display();
		d2.display();

	}

}

class DefEg {
	
	int Sid;
	String Sname;

void display() {
	System.out.println(Sid +" "+Sname);
	}
}
	

