package com.ecommerce.tests;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledIf;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;
import org.junit.jupiter.api.function.Executable;
//import org.junit.platform.runner.JUnitPlatform;
//import org.junit.runner.RunWith;
import org.junit.jupiter.api.DynamicTest.*;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.api.Assertions;
 
@DisplayName("JUnit 5 Dynamic Tests Example")
//@RunWith(JUnitPlatform.class)
public class DynamicTests {

	@TestFactory
	Collection<DynamicTest> dynamicTestsWithCollection() {
	    return Arrays.asList(
	      DynamicTest.dynamicTest("Add test",
	        () -> assertEquals(2, Math.addExact(1, 1))),
	      DynamicTest.dynamicTest("Multiply Test",
	        () -> assertEquals(4, Math.multiplyExact(2, 2))));
	}

	private Object assertEquals(int i, int addExact) {
		// TODO Auto-generated method stub
		return null;
	}
	

}

class MyExecutable implements Executable {
    @Override
    public void execute() throws Throwable {
            System.out.println("Hello World!");
    }
}
