package oops;

class EncapsulationImp {
	
    private String Name; 
    private String Roll; 
    private int Age;
    
    public void setName(String newName) {
    	Name = newName;
    }
    
    public void setRoll(String newRoll) {
    	Roll = newRoll;
    }
    
    public void setAge(int newAge) {
    	Age = newAge;
    }
    
    public String getName() {
    	return Name;
    }
    
    public String getRoll() {
    	return Roll;
    }
    
    public int getAge() {
    	return Age;
    }

}
public class Encapsulation{
	
public static void main(String[] args) {
		
		EncapsulationImp e = new EncapsulationImp();
		
		e.setName("Dilip"); 
        e.setAge(23); 
        e.setRoll("Developer"); 
		
		System.out.println("My name: " + e.getName()); 
        System.out.println("My age: " + e.getAge()); 
        System.out.println("My roll: " + e.getRoll());      
	}
	
}

	


