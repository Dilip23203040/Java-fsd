package oops;

public class Polymorphism {
	
	public double calci(int x, int y) {
		return x+y;
	}
	
	public double calci(double y, double z) {
		return y-z;
	}
	
	public double calci(int x, int y, int z) {
		return x*y*z;
	}

	public static void main(String[] args) {
		
		Polymorphism p = new Polymorphism();
		
		System.out.println(p.calci(50, 89) + "\n" + p.calci(85, 68) + "\n" + p.calci(5, 2, 10));
		
	}

}
