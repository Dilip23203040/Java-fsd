package oops;

public class ClassObjects {
	
	int sid;
	String sname;
	String Branch;
	
	ClassObjects(int sid, String sname, String Branch){
		
		this.sid = sid;
		this.sname = sname;
		this.Branch = Branch;
		
	}
	
	public int getSid() {
		return sid;
	}
	
	public String getName() {
		return sname;
	}
	
	public String getBranch() {
		return Branch;
	}
	
	@Override
	
	public String toString() {
		
		return " Hi My name is " + this.getName() + " bearing of id " + this.getSid()
		+ " and my branch is " + this.getBranch();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassObjects co1 = new ClassObjects(538, "Dilip", "CSE");
		ClassObjects co2 = new ClassObjects(334, "Revanth", "MECH");
		
		System.out.println(co1.toString() +"\n");
		System.out.println(co2.toString());
		
	}

}
