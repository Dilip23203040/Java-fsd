package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VacationCenterSpringBootRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(VacationCenterSpringBootRestApiApplication.class, args);
		
		System.out.println("Spring Boot Up..............");
	}

}
