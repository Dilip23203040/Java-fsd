package com.vc.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class VaccineCenter {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name = "center")
	private String center;
	@Column(name = "city")
	private String city;
	
	public VaccineCenter() {
		super();
		// TODO Auto-generated constructor stub
	}

	public VaccineCenter(Long id, String center, String city) {
		super();
		this.id = id;
		this.center = center;
		this.city = city;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCenter() {
		return center;
	}

	public void setCenter(String center) {
		this.center = center;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "VaccineCenter [id=" + id + ", center=" + center + ", city=" + city + "]";
	}
	
	
	
	

}
