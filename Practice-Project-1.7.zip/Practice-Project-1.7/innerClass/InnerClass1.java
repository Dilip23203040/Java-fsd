package innerClass;

public class InnerClass1 {
	
	private String msg = "Welcome to Inner class";
	
	class Inner {
		void disp() {
			System.out.println(msg);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		InnerClass1 c1 = new InnerClass1();
		
		InnerClass1.Inner c2 = c1. new Inner();
		
		c2.disp();

	}

}
