package innerClass;

public class InnerClass3 {
	
	

	public static void main(String[] args) {
		
		
		AnonymousInnerClass a = new AnonymousInnerClass(){
			
			public void disp() {
				
				System.out.println("Anonymous Inner Class");
			}
			
		};
		
		a.disp();
			
			
		}
		

	}




abstract class AnonymousInnerClass {
	
	public abstract void disp();
	
}