package innerClass;

public class InnerClass2 {
	
	private String msg = "Inner class inside a method";
	
	void disp() {
		
		class Inner{
			void msg() {
				System.out.println(msg);
			}
		}
		
		Inner l1 = new Inner();
		l1.msg();
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		InnerClass2 c = new InnerClass2();
		
		c.disp();

	}

}
